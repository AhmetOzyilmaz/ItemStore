package itemzhop;

public class ItemIncomingOffer {
    public Item item;
    public int price;

    public ItemIncomingOffer(Item item, int price) {
        this.item = item;
        this.price = price;
    }
}
